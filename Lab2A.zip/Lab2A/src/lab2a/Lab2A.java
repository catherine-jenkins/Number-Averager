package lab2a;
import java.util.Scanner;


public class Lab2A {

    public static void main(String[] args) {
     
        System.out.println("Please enter ten integers between 1 and 100, and I will tell you the smallest,"
                + " the largest, and the average: \n");
        
        Scanner inputNumbers = new Scanner(System.in);
        
        int smallestValue = 100, largestValue = 0, runningTotal = 0;
        
        for (int i = 0; i < 10; i++){
            
           int userNumbers = inputNumbers.nextInt();
           runningTotal += userNumbers;
        
           if (userNumbers < smallestValue){
                
            smallestValue = userNumbers;
           }    
           else if (userNumbers > largestValue){
                    
            largestValue = userNumbers;
           }
        } 
        
        double average = runningTotal / 10.0;
        
        System.out.println( "\nSmallest: " + smallestValue);
        System.out.println("Largest: " + largestValue);
        System.out.println("Average: " + average);
        }
       
        
        

        

        

           
           
                

    
}   
        
        
 